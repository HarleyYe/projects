package manager;
import javax.imageio.ImageIO;
import javax.swing.*;
import java.awt.*;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.awt.event.ComponentAdapter;
import java.awt.event.ComponentEvent;
import java.awt.image.BufferedImage;
import java.io.*;
import java.io.FileOutputStream;
import java.io.IOException;
import java.io.PrintWriter;
import java.util.*;
public class Manager {

    static Listener createDrawListener;
    public JFrame frame;
    int width;
    int height;
    private String file ="./save/white_board";
    static Manager createWhiteBoard;
    static CanvasPainter canvas;
    @SuppressWarnings("rawtypes")
    public JList list;
    public static int curX, curY;
    public static JTextArea chatArea;

    ImageIcon line = new ImageIcon(Manager.class.getResource("/Icon/line.png"));
    ImageIcon circle = new ImageIcon(Manager.class.getResource("/Icon/circle.png"));
    ImageIcon rect = new ImageIcon(Manager.class.getResource("/Icon/rect.png"));
    ImageIcon oval = new ImageIcon(Manager.class.getResource("/Icon/oval.png"));
    ImageIcon pencil = new ImageIcon(Manager.class.getResource("/Icon/pencil.png"));
    ImageIcon more = new ImageIcon(Manager.class.getResource("/Icon/color.png"));
    ImageIcon[] icons ={line, circle, rect, oval, pencil};

    public Manager(String mName){
        initialize(mName);
    }

    public Manager(){
    }

    public int showRequest(String name){
        int option = JOptionPane.showConfirmDialog(null,
                name +" wants to share your white board", "confirm",JOptionPane.INFORMATION_MESSAGE);
        return option;
    }

    @SuppressWarnings({"unchecked", "rawtypes"})
    private void initialize(String name){
        frame = new JFrame();
        frame.setTitle("Distributed Whiteboard (Manager): "+name);
        frame.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
        frame.setBounds(100,100,1600,800);
        createDrawListener = new Listener(frame);
        JPanel toolPanel = new JPanel();
        toolPanel.setBounds(0,0,80,450);
        toolPanel.setLayout(new FlowLayout(FlowLayout.LEFT));

        //menu
        JComboBox menu = new JComboBox();
        menu.setModel(new DefaultComboBoxModel(new String[]{"New", "Save", "Save as", "Open", "Exit"}));
        menu.addActionListener(e ->{
            if (menu.getSelectedItem().toString().equals("New")){
                canvas.removeAll();
                canvas.updateUI();
                createDrawListener.clearRecord();
                try{
                    ConnectionManager.broadcast("new");
                }catch (IOException e1){
                    e1.printStackTrace();
                }
                System.out.println("New White board");
            }else if (menu.getSelectedItem().toString().equals("Save")){
                saveFile();
            }else if (menu.getSelectedItem().toString().equals("Save as")){
                FrameSaveFile saveAs = new FrameSaveFile(createWhiteBoard);
                saveAs.frmSaveAs.setVisible(true);
            }else if (menu.getSelectedItem().toString().equals("Open")){
                FrameOpenFile open = new FrameOpenFile(createWhiteBoard);
                open.frmOpen.setVisible(true);
            }else if (menu.getSelectedItem().toString().equals("Exit")) {
                System.exit(1);
            }
        });
        toolPanel.add(menu);

        //Tools
        String[] tools ={"Line", "Circle", "Rect", "Oval", "Free"};
        for (int i=0; i<tools.length; i++){
            JButton button1 = new JButton("");
            button1.setActionCommand(tools[i]);
            button1.setPreferredSize(new Dimension(60, 30));
            @SuppressWarnings("static-access")
            Image temp = icons[i].getImage().getScaledInstance(21, 21, icons[i].getImage().SCALE_DEFAULT);
            icons[i] = new ImageIcon(temp);
            button1.setIcon(icons[i]);
            button1.addActionListener(createDrawListener);
            toolPanel.add(button1);
        }

        //text
        JButton text = new JButton("A");
        text.setFont(new Font(null, 0,20));
        text.setPreferredSize(new Dimension(60, 30));
        text.addActionListener(createDrawListener);
        if (text != null){
            toolPanel.add(text);
        }
        createDrawListener.setThickness(6);

        frame.getContentPane().setLayout(null);
        frame.getContentPane().add(toolPanel);
        canvas = new CanvasPainter();
        canvas.setBorder(null);
        canvas.setBounds(100,0,1050,780);
        width = canvas.getWidth();
        height = canvas.getHeight();
        canvas.setBackground(Color.WHITE);
        canvas.setList(createDrawListener.getRecord());
        frame.getContentPane().add(canvas);
        canvas.setLayout(null);
        frame.setVisible(true);
        frame.setResizable(false);
        canvas.addMouseListener(createDrawListener);
        canvas.addMouseMotionListener(createDrawListener);
        createDrawListener.setG(canvas.getGraphics());

        JButton btnMore = new JButton("");
        btnMore.setActionCommand("More");
        btnMore.setPreferredSize(new Dimension(27, 27));
        @SuppressWarnings("static-access")
        Image temp = more.getImage().getScaledInstance(22, 22, more.getImage().SCALE_DEFAULT);
        more = new ImageIcon(temp);
        btnMore.setIcon(more);

        toolPanel.add(btnMore);
        btnMore.addActionListener(createDrawListener);

        list = new JList<Object>();
        String uname =name;
        frame.getContentPane().add(list);
        String[] mname ={uname};
        list.setListData(mname);
        JScrollPane ScrollList = new JScrollPane(list);
        ScrollList.setBounds(0, 500, 100, 200);
        ScrollList.setVerticalScrollBarPolicy(JScrollPane.VERTICAL_SCROLLBAR_ALWAYS);
        frame.getContentPane().add(ScrollList);
        JButton btnKick = new JButton("Kick Out");
        btnKick.addActionListener(e ->{
            String user = list.getSelectedValue().toString();
            if(name.equals(user)){
                return;
            }
            for (int i= 0; i< RunServer.connections.size();i++){
                Connection tt = RunServer.connections.get(i);
                if (user.equals(tt.name)) {
                    tt.kick = true;
                    try{
                        tt.dos.writeUTF("kick " + tt.name);
                        tt.dos.flush();
                    } catch(IOException e2){
                        e2.printStackTrace();
                    }
                    try{
                        tt.socket.close();
                    } catch(IOException e1){
                        e1.printStackTrace();
                    }
                    RunServer.connections.remove(i);
                    RunServer.usernames.remove(user);
                    JOptionPane.showMessageDialog(frame, user + " is kicked out!");

                }
            }
            for (String userName : RunServer.usernames){
                user += " " + userName;
            }
            for (int i = 0; i< RunServer.connections.size(); i++){
                Connection tt = RunServer.connections.get(i);
                try{
                    tt.dos.writeUTF("delete " + user);
                    tt.dos.flush();
                } catch(IOException e1){
                    e1.printStackTrace();
                }
            }
            String[] k1 =user.split(" ", 2);
            String[] kkk=k1[1].split(" ");
            list.setListData(kkk);
        });
        btnKick.setBounds(0,720,100,30);
        frame.getContentPane().add(btnKick);

        //chat
        chatArea = new JTextArea();
        chatArea.setBounds(1250,0,300, 650);
        chatArea.setEnabled(false);
        frame.getContentPane().add(chatArea);

        JTextField inputField = new JTextField();
        inputField.setBounds(1250, 700, 200, 50);
        frame.getContentPane().add(inputField);

        JButton sendMsgBtn = new JButton("SEND");
        sendMsgBtn.setBounds(1450, 700, 100, 50);
        frame.getContentPane().add(sendMsgBtn);
        sendMsgBtn.addActionListener(new ActionListener(){
            public void actionPerformed(ActionEvent arg0){
                String msg = name + ": " + inputField.getText();
                chatArea.append(msg + "\n");
                for (int i = 0; i< RunServer.connections.size();i++){
                    Connection tt = RunServer.connections.get(i);
                    try{
                        tt.dos.writeUTF("chat "+msg);
                        tt.dos.flush();
                    } catch(IOException e1){
                        e1.printStackTrace();
                    }
                }
                inputField.setText("");
            }
        });

    }

    @SuppressWarnings("static-access")
    void setFrame(Manager createWhiteBoard){
        this.createWhiteBoard = createWhiteBoard;
    }

    public void saveFile(String file){
        this.file = "./" + file;
        this.saveFile();
    }

    public void saveFile(){
        PrintWriter outputStream = null;
        try{
            outputStream = new PrintWriter(new FileOutputStream(file));

        }catch(IOException e1){
            System.out.println("Error opening the file "+ file +".");
            return;
        }
        ArrayList<String> recordList=createDrawListener.getRecord();
        for (String record : recordList){
            outputStream.println(record);
        }
        outputStream.flush();
        outputStream.close();
        System.out.println("Saved");
    }

    public void saveImg(String file, String format){
        BufferedImage targetImg = new BufferedImage(width, height, BufferedImage.TYPE_INT_RGB);
        Graphics2D g = targetImg.createGraphics();
        g.setColor(Color.white);
        g.fillRect(0,0,width, height);
        ArrayList<String> recordList = createDrawListener.getRecord();
        canvas.draw(g, recordList);

        try{
            if (format.equals(".jpg")){
                ImageIO.write(targetImg, "JPEG", new File("./" + file + format));
            } else if (format.equals(".png")){
                ImageIO.write(targetImg, "PNG", new File("./" + file + format));
            }
        } catch (IOException e1){
            System.out.println("Wrong file.");
        }
        System.out.println("saved");
    }

    public void openFile(String file){
        file = "./" + file;
        Scanner inputStream = null;
        try{
            inputStream = new Scanner(new FileInputStream(file));
        }catch(FileNotFoundException ee) {
            System.out.println("Problem opening files.");
            return;
        }
        createDrawListener.clearRecord();
        while (inputStream.hasNextLine()){
            String line = inputStream.nextLine();
            createDrawListener.update(line);
        }

        try{
            ConnectionManager.broadcast("new");
        }catch(IOException e1){
            e1.printStackTrace();
        }
        ArrayList<String> rl=createDrawListener.getRecord();
        try{
            ConnectionManager.broadcastBatch(rl);
        } catch(IOException e1){
            e1.printStackTrace();
        }

        canvas.repaint();
        inputStream.close();
    }
}








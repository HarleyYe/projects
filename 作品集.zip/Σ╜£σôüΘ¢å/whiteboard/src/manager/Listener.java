package manager;

import javax.swing.*;
import java.awt.*;
import java.awt.event.*;
import java.io.IOException;
import java.util.ArrayList;


public class Listener implements ActionListener, MouseListener, MouseMotionListener {

    Graphics2D g;
    JFrame frame;
    int startX, startY, endX, endY;
    int t=1;
    Object type = "Line";
    static Color color = Color.BLACK;
    String rgb = "0 0 0";
    String record;
    ArrayList<String> recordList = new ArrayList<>();

    public Listener(){

    }

    public Listener(JFrame frame){
        this.frame = frame;
    }

    @Override
    public void actionPerformed(ActionEvent e) {
        if (e.getActionCommand().equals("More")){
            final JFrame jf = new JFrame("Color Penal");
            jf.setSize(300, 300);
            jf.setLocationRelativeTo(null);
            jf.setDefaultCloseOperation(WindowConstants.EXIT_ON_CLOSE);
            Color curColor = JColorChooser.showDialog(jf, "Choose color", null);
            if (curColor != null){
                color = curColor;
            }
        } else{
            this.type = e.getActionCommand();
            if (type.equals("Free")){
                Cursor cur = new Cursor(Cursor.DEFAULT_CURSOR);
                frame.setCursor(cur);
            } else if (type.equals("Oval")){
                Cursor cur = new Cursor(Cursor.CROSSHAIR_CURSOR);
                frame.setCursor(cur);
            } else if (type.equals("T")){
                Cursor cur = new Cursor(Cursor.DEFAULT_CURSOR);
                frame.setCursor(cur);
            } else if (type.equals("Circle")){
                Cursor cur = new Cursor(Cursor.CROSSHAIR_CURSOR);
                frame.setCursor(cur);
            }else if (type.equals("Rect")){
                Cursor cur = new Cursor(Cursor.CROSSHAIR_CURSOR);
                frame.setCursor(cur);
            }else if (type.equals("Line")){
                Cursor cur = new Cursor(Cursor.CROSSHAIR_CURSOR);
                frame.setCursor(cur);
            }
        }
    }

    @Override
    public void mousePressed(MouseEvent e) {
        startX=e.getX();
        startY=e.getY();
        if (!g.getColor().equals(color)){
            g.setColor(color);
        }
        if (type.equals("Free")){
            rgb = getColor(color);
            g.setStroke(new BasicStroke(t));
            g.drawLine(startX, startY, startX, startY);
            record = "Line "+this.t+" "+rgb +" "+startX +" "+startY +" "+startX +" "+startY+" !";
            recordList.add(record);
        }
    }

    @Override
    public void mouseReleased(MouseEvent e) {
        endX = e.getX();
        endY = e.getY();
        if (this.type.equals("Line")){
            rgb = getColor(color);
            g.setStroke(new BasicStroke(t));
            g.drawLine(startX, startY, endX, endY);
            record = "Line " + this.t +" "+rgb +" "+startX +" "+startY+" "+endX +" "+endY+" !";
            recordList.add(record);
        }else if (type.equals("Circle")){
            //Draw circle
            rgb = getColor(color);
            g.setStroke(new BasicStroke(t));
            int diameter = (int)Math.sqrt(Math.pow(endX-startX,2)+Math.pow(endY-startY,2));
            g.drawOval(startX-diameter,startY-diameter,2*diameter, 2*diameter);
            record = "Circle "+ this.t+" "+rgb+" "+startX+" "+startY+" "+endX+" "+endY+" !";
            recordList.add(record);
        }else if (type.equals("Oval")){
            rgb = getColor(color);
            g.setStroke(new BasicStroke(t));
            int width =Math.abs(endX-startX);
            int height = Math.abs(endY-startY);
            g.drawOval(startX-width,startY-height, 2*width, 2*height);
            record="Oval "+this.t+" "+rgb +" "+startX+" "+startY+" "+endX+" "+endY+" !";
            recordList.add(record);
        }else if (type.equals("A")){
            String text = JOptionPane.showInputDialog("Please Enter Input Text");
            if (text != null){
                Font f = new Font(null, Font.PLAIN, this.t+10);
                g.setFont(f);
                g.drawString(text, endX, endY);
                rgb = getColor(color);
                record = "Text "+ this.t +" "+rgb+" "+endX +" "+endY+" "+text +" !";
                recordList.add(record);
            }
        }else if (type.equals("Rect")){
            rgb = getColor(color);
            g.setStroke(new BasicStroke(t));
            g.drawRect(Math.min(startX, endX), Math.min(startY, endY), Math.abs(startX - endX),
                    Math.abs(startY-endY));
            record = "Rect " + this.t +" "+rgb + " "+ startX+" "+startY+" "+endX+" "+endY+" !";
            recordList.add(record);
        }else{
            return;
        }
        try{
            ConnectionManager.broadcast("draw "+record);
        }catch (IOException e1){
            e1.printStackTrace();
        }
    }

    public void mouseDragged(MouseEvent e) {
        endX=e.getX();
        endY=e.getY();
        if (type.equals("Free")){
            rgb = getColor(color);
            g.setStroke(new BasicStroke(t));
            g.drawLine(startX, startY, endX, endY);
            record = "Line "+ this.t + " "+rgb +" "+ startX +" "+startY +" "+endX+" "+endY+" !";
            recordList.add(record);
            startX=endX;
            startY=endY;
        }else{
            return;
        }
        try{
            ConnectionManager.broadcast("draw "+ record);
        }catch(IOException e1){
            e1.printStackTrace();
        }
    }

    public void setG(Graphics g){
        this.g =(Graphics2D) g;
    }

    @Override
    public void mouseClicked(MouseEvent e) {
    }

    @Override
    public void mouseEntered(MouseEvent e) {
    }

    @Override
    public void mouseExited(MouseEvent e) {
    }

    @Override
    public void mouseMoved(MouseEvent e) {
    }

    public ArrayList<String> getRecord(){
        return recordList;
    }

    public void update(String line){
        recordList.add(line);
    }

    public void clearRecord(){
        recordList.clear();
    }

    public void setThickness(int t){
        this.t = t;
    }

    public int getThickness(){
        return this.t;
    }

    private String getColor(Color color){
        return color.getRed() + " "+color.getGreen()+" "+ color.getBlue();
    }
}

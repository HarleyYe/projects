package manager;

import javax.swing.*;
import java.io.*;
import java.net.Socket;
import java.net.SocketException;
import java.util.ArrayList;

public class Connection extends Thread{

    public Socket socket;
    public String name;
    public DataInputStream dis;
    public DataOutputStream dos;

    public boolean kick = false;

    public Connection(Socket socket){
        this.socket = socket;
    }






    public void run(){
        try{
            InputStream ins = socket.getInputStream();
            OutputStream ous = socket.getOutputStream();
            dis = new DataInputStream(ins);
            dos = new DataOutputStream(ous);
            String str1;
            label:
            while ((str1=dis.readUTF()) != null){
                String[] out=str1.split(" ", 2);
                switch (out[0]){
                    case "begin":

                        ArrayList<String> rl =Create.createWhiteBoard.createDrawListener.getRecord();
                        try{
                            ConnectionManager.broadcastBatch(rl);
                        } catch(IOException e1){
                            e1.printStackTrace();
                        }
                        String str = "userlist";
                        for (String userName: RunServer.usernames){
                            str += " "+userName;
                        }
                        String[] k= str.split(" ", 2);
                        String[] clients =k[1].split(" ");
                        ConnectionManager.addUser(clients);
                        ConnectionManager.broadcast(str);
                        break;
                    case "request":
                        String curName = out[1];
                        name =curName;
                        if(RunServer.usernames.contains(curName)){
                            dos.writeUTF("feedback no");
                            dos.flush();
                        }else {
                            int ans = ConnectionManager.checkin(out[1]);
                            if(ans == JOptionPane.YES_OPTION){
                                if(RunServer.usernames.contains(curName)){
                                    try{
                                        dos.writeUTF("feedback no");
                                        dos.flush();
                                        RunServer.connections.remove(this);
                                        socket.close();
                                        break;
                                    } catch(Exception e1){
                                        RunServer.connections.remove(this);
                                    }
                                }else{
                                    RunServer.usernames.add(curName);
                                    dos.writeUTF("feedback yes");
                                    dos.flush();
                                }
                            }else if (ans == JOptionPane.CANCEL_OPTION || ans ==JOptionPane.CLOSED_OPTION ||
                                    ans == JOptionPane.NO_OPTION){
                                dos.writeUTF("feedback rejected");
                                dos.flush();
                                RunServer.connections.remove(this);
                            }
                        }
                        break;
                    case "draw":
                        ConnectionManager.broadcast(str1);
                        ConnectionManager.canvasRepaint(out[1]);
                        break;
                    case "over":
                        socket.close();
                        break label;
                    case "chat":
                        ConnectionManager.broadcast(str1);
                        Manager.chatArea.setText(Manager.chatArea.getText()+"\n"+out[1]);
                        break;
                }
                if (out[0].equals("new")){
                    Manager.canvas.removeAll();
                    Manager.canvas.updateUI();
                    Manager.createDrawListener.clearRecord();
                }
            }

        }catch (SocketException e){
            System.out.println("User " +this.name +" Connection interruption ");
            if (!this.kick){
                clientout();
            }
        }catch (Exception w){
            System.out.println("User "+ this.name +" Connection interruption");
        }
    }

    public void clientout(){
        RunServer.connections.remove(this);
        RunServer.usernames.remove(name);
        String str ="clientout" + name;
        for (String userName: RunServer.usernames){
            str +=" "+userName;
        }
        for (int i=0; i<RunServer.connections.size();i++){
            Connection st = RunServer.connections.get(i);
            try{
                st.dos.writeUTF(str);
                dos.flush();
            } catch(IOException e){
                e.printStackTrace();
            }
        }
        String k =str.split(" ", 2)[1];
        ConnectionManager.clientOut(k);
    }

}

package manager;
import java.awt.EventQueue;
import javax.swing.JButton;
import javax.swing.JFrame;
import javax.swing.JLabel;
import javax.swing.JTextField;

public class Create {

    static String address;
    static int port;
    static String username;
    public static Manager createWhiteBoard;

    private JFrame frame;
    private JTextField textField;

    public static void main(String[] args){

        if (args.length >= 3) {
            try{
                address = args[0];
                port = Integer.parseInt(args[1]);
                username = args[2];
            }catch (Exception e){
                System.out.println("Type error.");
                System.exit(1);
            }
        } else {
            address = "localhost";
            port = 8080;
            username = "Manager";
            System.out.println("Launch by default.");
        }
        EventQueue.invokeLater(() -> {
            try {
                new Create();
            } catch (Exception e) {
                e.printStackTrace();
            }
        });
        RunServer.launch(port, username);
    }

    public Create(){
        initialize();
    }

    private void initialize(){

        Listener createDrawListener = new Listener();

        frame = new JFrame();
        frame.setBounds(800, 400, 450, 300);
        frame.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);

        JButton loginButton = new JButton("LOGIN");
        loginButton.setBounds(150,150,150,60);

        JLabel usernameLabel = new JLabel("Input your username:");
        usernameLabel.setBounds(150,25,200,50);
        frame.getContentPane().add(usernameLabel);

        textField = new JTextField();
        textField.setBounds(80, 70, 280, 50);
        frame.getContentPane().add(textField);
        textField.setText(username);

        loginButton.addActionListener(createDrawListener);
        loginButton.addActionListener(e ->{
            if (e.getActionCommand().equals("LOGIN")){
                username = textField.getText();
                frame.dispose();
                try{
                    createWhiteBoard = new Manager(username);
                    createWhiteBoard.setFrame(createWhiteBoard);

                }catch (Exception e1){
                    e1.printStackTrace();
                }
            }
        });

        frame.getContentPane().setLayout(null);
        frame.getContentPane().add(loginButton);
        frame.setVisible(true);

    }

}

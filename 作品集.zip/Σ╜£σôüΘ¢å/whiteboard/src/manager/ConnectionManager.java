package manager;

import javax.swing.*;
import java.io.IOException;
import java.util.ArrayList;

public class ConnectionManager {


    public static synchronized int checkin(String name){
        int ans = Create.createWhiteBoard.showRequest(name);
        return ans;
    }


    public static void addUser(String[] clients){

        Create.createWhiteBoard.list.setListData(clients);

    }


    public static void clientOut(String clients){

        String[] k =clients.split(" ", 2);
        JOptionPane.showMessageDialog(Create.createWhiteBoard.frame, "user "+k[0]+ " leaves!");
        String[] client=k[1].split(" ");
        Create.createWhiteBoard.list.setListData(client);

    }

    public static void canvasRepaint(String drawRecord){
        Manager.createDrawListener.update(drawRecord);
        Manager.canvas.repaint();
    }

    public static void broadcast(String message) throws IOException{
        for (int i = 0;i<RunServer.connections.size();i++){
            Connection st =RunServer.connections.get(i);
            st.dos.writeUTF(message);
            st.dos.flush();
        }
    }

    public static void broadcastBatch(ArrayList<String> recordList) throws IOException{
        String[] recordArray = recordList.toArray(new String[recordList.size()]);
        for (String message : recordArray){
            for (int i =0;i<RunServer.connections.size();i++){
                Connection st = RunServer.connections.get(i);
                st.dos.writeUTF("draw "+message);
                st.dos.flush();
            }
        }
    }
}

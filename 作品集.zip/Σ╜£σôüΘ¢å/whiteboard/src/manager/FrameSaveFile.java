package manager;
import javax.swing.*;

public class FrameSaveFile {

    JFrame frmSaveAs;
    private JTextField textField;
    private Manager whiteBoard;

    public FrameSaveFile(){
        initialize();
    }

    public FrameSaveFile(Manager whiteBoard){
        this.whiteBoard=whiteBoard;
        initialize();
    }


    private void initialize(){
        frmSaveAs=new JFrame();
        frmSaveAs.setTitle("Save");
        frmSaveAs.setBounds(100,100,400,200);
        frmSaveAs.setDefaultCloseOperation(JFrame.DISPOSE_ON_CLOSE);
        frmSaveAs.getContentPane().setLayout(null);

        JLabel lblSaveAsfile = new JLabel("Save as:");
        lblSaveAsfile.setHorizontalAlignment(SwingConstants.CENTER);
        lblSaveAsfile.setBounds(30,54,82,27);
        frmSaveAs.getContentPane().add(lblSaveAsfile);

        JComboBox comboBox = new JComboBox();
        comboBox.setModel(new DefaultComboBoxModel(new String[]{".jpg", ".png"}));
        comboBox.setBounds(230, 54, 100, 26);
        frmSaveAs.getContentPane().add(comboBox);

        JButton btnSave = new JButton("OK");
        btnSave.addActionListener(e ->{
            String name = textField.getText();
            String format = comboBox.getSelectedItem().toString();
            whiteBoard.saveFile(name);
            whiteBoard.saveImg(name, format);
            frmSaveAs.dispose();
        });
        btnSave.setBounds(150, 120, 82,29);
        frmSaveAs.getContentPane().add(btnSave);

        textField = new JTextField();
        textField.setBounds(125, 54, 130, 26);
        frmSaveAs.getContentPane().add(textField);
        textField.setColumns(10);
        textField.setText("white_board");

    }
}

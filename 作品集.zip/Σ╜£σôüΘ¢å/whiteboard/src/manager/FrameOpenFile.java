package manager;
import javax.swing.*;
import java.awt.*;
import java.io.FileInputStream;
import java.io.FileNotFoundException;
import java.util.Scanner;

public class FrameOpenFile {

    JFrame frmOpen;
    private JTextField txtFilename;
    private JTextField txtNotExist;
    private Manager whiteBoard;

    public FrameOpenFile(){
        initialize();
    }

    public FrameOpenFile(Manager whiteBoard){
        this.whiteBoard=whiteBoard;
        initialize();
    }


    private void initialize(){
        frmOpen=new JFrame();
        frmOpen.setTitle("Open File");
        frmOpen.setBounds(100,100,450,200);
        frmOpen.setDefaultCloseOperation(JFrame.DISPOSE_ON_CLOSE);
        frmOpen.getContentPane().setLayout(null);

        JButton btnNewButton = new JButton("open");
        btnNewButton.setBounds(300, 60, 100,35);
        frmOpen.getContentPane().add(btnNewButton);

        txtFilename = new JTextField();
        txtFilename.setText("white_board");
        txtFilename.setBounds(77, 60, 168, 35);
        frmOpen.getContentPane().add(txtFilename);
        txtFilename.setColumns(10);

        JLabel lblOpenFile = new JLabel("Input File path");
        lblOpenFile.setBounds(85,36,128,16);
        frmOpen.getContentPane().add(lblOpenFile);

        txtNotExist=new JTextField();
        txtNotExist.setForeground(SystemColor.inactiveCaptionText);
        txtNotExist.setHorizontalAlignment(SwingConstants.CENTER);
        txtNotExist.setEditable(false);
        txtNotExist.setBackground(SystemColor.control);
        txtNotExist.setText("File does not exist!");
        txtFilename.setBounds(103,218,238,26);
        txtFilename.setBorder(null);
        frmOpen.getContentPane().add(txtNotExist);
        txtNotExist.setColumns(10);
        txtNotExist.setVisible(false);

        btnNewButton.addActionListener(e ->{
            String name = txtFilename.getText();
            String file = name;
            try{
                new Scanner(new FileInputStream(file));
            }catch(FileNotFoundException e1){
                txtNotExist.setVisible(true);
                JOptionPane.showMessageDialog(frmOpen, "no such file exist");
                return;
            }
            whiteBoard.openFile(file);
            frmOpen.dispose();
        });
    }
}

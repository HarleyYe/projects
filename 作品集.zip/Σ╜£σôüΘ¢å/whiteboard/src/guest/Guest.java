package guest;
import javax.imageio.ImageIO;
import javax.swing.*;
import java.awt.*;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.awt.event.ComponentAdapter;
import java.awt.event.ComponentEvent;
import java.awt.image.BufferedImage;
import java.io.*;
import java.io.FileOutputStream;
import java.io.IOException;
import java.io.PrintWriter;
import java.util.*;

public class Guest {

    public JTextArea guestTextArea;
    public Connection connection;
    static guest.Listener listener;
    static CanvasPainter canvasPainter;
    private String guestUsername;
    //int x
    //int y

    //static guest.Listener createDrawListener;
    public JFrame frame;
    int width;
    int height;
    static guest.Guest createWhiteBoard;
    //static CanvasPainter canvas;
    public JList list;
    public static int curX, curY;
    //public static JTextArea chatArea;

    /**
    ImageIcon line = new ImageIcon(guest.Guest.class.getResource("/Icon/line.png"));
    ImageIcon circle = new ImageIcon(guest.Guest.class.getResource("/Icon/circle.png"));
    ImageIcon rect = new ImageIcon(guest.Guest.class.getResource("/Icon/rect.png"));
    ImageIcon oval = new ImageIcon(guest.Guest.class.getResource("/Icon/oval.png"));
    ImageIcon pencil = new ImageIcon(guest.Guest.class.getResource("/Icon/pencil.png"));
    ImageIcon more = new ImageIcon(guest.Guest.class.getResource("/Icon/color.png"));
    ImageIcon[] icons ={line, circle, rect, oval, pencil};
**/

    public Guest(Connection connection, String mName){
        this.connection=connection;
        this.guestUsername=mName;
        initialize(mName);
    }
    public Guest(Connection connection){
    }

    public void initialize(String name){
        frame = new JFrame();
        frame.setTitle("Distributed Whiteboard (User): "+name);
        frame.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
        frame.setBounds(100,100,1600,800);
        listener = new Listener(frame);
        JPanel toolPanel = new JPanel();
        toolPanel.setBounds(0,0,80,450);
        toolPanel.setLayout(new FlowLayout(FlowLayout.LEFT));
        ImageIcon line = new ImageIcon(guest.Guest.class.getResource("/Icon/line.png"));
        ImageIcon circle = new ImageIcon(guest.Guest.class.getResource("/Icon/circle.png"));
        ImageIcon rect = new ImageIcon(guest.Guest.class.getResource("/Icon/rect.png"));
        ImageIcon oval = new ImageIcon(guest.Guest.class.getResource("/Icon/oval.png"));
        ImageIcon pencil = new ImageIcon(guest.Guest.class.getResource("/Icon/pencil.png"));
        ImageIcon more = new ImageIcon(guest.Guest.class.getResource("/Icon/color.png"));
        ImageIcon[] icons ={line, circle, rect, oval, pencil};
        commonUI(toolPanel, more, icons);
        try{
            connection.dos.writeUTF("begin .");
            connection.dos.flush();
        } catch (IOException e) {
            e.printStackTrace();
        }
    }

    private void commonUI(JPanel toolPanel, ImageIcon more, ImageIcon[] icons){
        String[] tools ={"Line", "Circle", "Rect", "Oval", "Free"};
        for (int i=0; i<tools.length; i++){
            JButton button1 = new JButton("");
            button1.setActionCommand(tools[i]);
            button1.setPreferredSize(new Dimension(60, 30));
            @SuppressWarnings("static-access")
            Image temp = icons[i].getImage().getScaledInstance(21, 21, icons[i].getImage().SCALE_DEFAULT);
            icons[i] = new ImageIcon(temp);
            button1.setIcon(icons[i]);
            button1.addActionListener(listener);
            toolPanel.add(button1);
        }
        JButton text = new JButton("A");
        text.setFont(new Font(null, 0,20));
        text.setPreferredSize(new Dimension(60, 30));
        text.addActionListener(listener);
        if (text != null){
            toolPanel.add(text);
        }

        JButton btnMore = new JButton("");
        btnMore.setActionCommand("More");
        btnMore.setPreferredSize(new Dimension(27, 27));
        @SuppressWarnings("static-access")
        Image temp = more.getImage().getScaledInstance(22, 22, more.getImage().SCALE_DEFAULT);
        more = new ImageIcon(temp);
        btnMore.setIcon(more);

        toolPanel.add(btnMore);
        btnMore.addActionListener(listener);

        listener.setThickness(6);
        frame.getContentPane().setLayout(null);
        frame.getContentPane().add(toolPanel);
        canvasPainter = new guest.CanvasPainter();
        canvasPainter.setBorder(null);
        canvasPainter.setBounds(100,0,1050,780);
        width = canvasPainter.getWidth();
        height = canvasPainter.getHeight();
        canvasPainter.setBackground(Color.WHITE);
        canvasPainter.setList(listener.getRecord());
        frame.getContentPane().add(canvasPainter);
        canvasPainter.setLayout(null);
        frame.setVisible(true);
        frame.setResizable(false);

        canvasPainter.addMouseListener(listener);
        canvasPainter.addMouseMotionListener(listener);
        listener.setG(canvasPainter.getGraphics());

        list=new JList();
        frame.getContentPane().add(list);

        JScrollPane ScrollList = new JScrollPane(list);
        ScrollList.setBounds(0, 500, 100, 200);
        ScrollList.setVerticalScrollBarPolicy(JScrollPane.VERTICAL_SCROLLBAR_ALWAYS);
        frame.getContentPane().add(ScrollList);

        //chat
        guestTextArea = new JTextArea();
        guestTextArea.setBounds(1250,0,300, 650);
        guestTextArea.setEnabled(false);
        frame.getContentPane().add(guestTextArea);

        JTextField inputField = new JTextField();
        inputField.setBounds(1250, 700, 200, 50);
        frame.getContentPane().add(inputField);

        JButton sendMsgBtn = new JButton("SEND");
        sendMsgBtn.setBounds(1450, 700, 100, 50);
        frame.getContentPane().add(sendMsgBtn);

        sendMsgBtn.addActionListener(new ActionListener(){
            public void actionPerformed(ActionEvent arg0){
                String msg = guestUsername + ": " + inputField.getText();
                //guestTextArea.append(msg + "\n");
                try {
                    connection.dos.writeUTF("chat "+msg);
                    connection.dos.flush();
                } catch (IOException e) {
                    e.printStackTrace();
                }
                inputField.setText("");
            }
        });





    }

/**
    public void initialize(String name){
        frame = new JFrame();
        frame.setTitle("Distributed Whiteboard (User): "+name);
        frame.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
        frame.setBounds(100,100,1600,800);
        listener = new Listener(frame);
        JPanel toolPanel = new JPanel();
        toolPanel.setBounds(0,0,80,450);
        toolPanel.setLayout(new FlowLayout(FlowLayout.LEFT));

        //Tools
        String[] tools ={"Line", "Circle", "Rect", "Oval", "Free"};
        for (int i=0; i<tools.length; i++){
            JButton button1 = new JButton("");
            button1.setActionCommand(tools[i]);
            button1.setPreferredSize(new Dimension(60, 30));
            @SuppressWarnings("static-access")
            Image temp = icons[i].getImage().getScaledInstance(21, 21, icons[i].getImage().SCALE_DEFAULT);
            icons[i] = new ImageIcon(temp);
            button1.setIcon(icons[i]);
            button1.addActionListener(listener);
            toolPanel.add(button1);
        }
        //text
        JButton text = new JButton("A");
        text.setFont(new Font(null, 0,20));
        text.setPreferredSize(new Dimension(60, 30));
        text.addActionListener(listener);
        if (text != null){
            toolPanel.add(text);
        }
        listener.setThickness(6);

        frame.getContentPane().setLayout(null);
        frame.getContentPane().add(toolPanel);
        canvasPainter = new guest.CanvasPainter();
        canvasPainter.setBorder(null);
        canvasPainter.setBounds(100,0,1050,780);
        width = canvasPainter.getWidth();
        height = canvasPainter.getHeight();
        canvasPainter.setBackground(Color.WHITE);
        canvasPainter.setList(listener.getRecord());
        frame.getContentPane().add(canvasPainter);
        canvasPainter.setLayout(null);
        frame.setVisible(true);
        frame.setResizable(false);
        canvasPainter.addMouseListener(listener);
        canvasPainter.addMouseMotionListener(listener);
        listener.setG(canvasPainter.getGraphics());

        JButton btnMore = new JButton("");
        btnMore.setActionCommand("More");
        btnMore.setPreferredSize(new Dimension(27, 27));
        @SuppressWarnings("static-access")
        Image temp = more.getImage().getScaledInstance(22, 22, more.getImage().SCALE_DEFAULT);
        more = new ImageIcon(temp);
        btnMore.setIcon(more);

        toolPanel.add(btnMore);
        btnMore.addActionListener(listener);

        list = new JList<Object>();
        String uname =name;
        frame.getContentPane().add(list);
        String[] mname ={uname};
        list.setListData(mname);

        JScrollPane ScrollList = new JScrollPane(list);
        ScrollList.setBounds(0, 500, 100, 200);
        ScrollList.setVerticalScrollBarPolicy(JScrollPane.VERTICAL_SCROLLBAR_ALWAYS);
        frame.getContentPane().add(ScrollList);

        //chat
        guestTextArea = new JTextArea();
        guestTextArea.setBounds(1250,0,300, 650);
        guestTextArea.setEnabled(false);
        frame.getContentPane().add(guestTextArea);

        JTextField inputField = new JTextField();
        inputField.setBounds(1250, 700, 200, 50);
        frame.getContentPane().add(inputField);

        JButton sendMsgBtn = new JButton("SEND");
        sendMsgBtn.setBounds(1450, 700, 100, 50);
        frame.getContentPane().add(sendMsgBtn);
        sendMsgBtn.addActionListener(new ActionListener(){
            public void actionPerformed(ActionEvent arg0){
                String msg = guestUsername + ": " + inputField.getText();
                guestTextArea.append(msg + "\n");
                try {
                    connection.dos.writeUTF("chat "+msg);
                    connection.dos.flush();
                } catch (IOException e) {
                    e.printStackTrace();
                }
                inputField.setText("");
            }
        });

    }**/



}

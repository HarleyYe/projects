package guest;
import javax.swing.*;
import java.awt.*;
import java.util.ArrayList;

public class CanvasPainter extends JPanel {
    /**
     *
     **/
    private static final long serialVersionID = 1L;
    private ArrayList<String> recordList = new ArrayList<>();

    public void setList(ArrayList<String> recordList){
        this.recordList =recordList;
    }

    public void paint(Graphics gr){
        super.paint(gr);
        draw((Graphics2D) gr, this.recordList);
    }

    public void draw(Graphics2D g, ArrayList<String> recordList){
        try{
            String[] recordArray=recordList.toArray(new String[recordList.size()]);
            for (String line:recordArray){
                String[] record =line.split(" ");
                int startX, startY, endX, endY, t, red, green, blue;
                Color color;
                if (record[1].equals("!")){
                    continue;
                }
                switch (record[0]){
                    case "Circle":
                        t=Integer.parseInt(record[1]);
                        g.setStroke(new BasicStroke(t));
                        red =Integer.parseInt(record[2]);
                        green = Integer.parseInt(record[3]);
                        blue = Integer.parseInt(record[4]);
                        color= new Color(red, green, blue);
                        g.setColor(color);
                        startX=Integer.parseInt(record[5]);
                        startY=Integer.parseInt(record[6]);
                        endX =Integer.parseInt(record[7]);
                        endY=Integer.parseInt(record[8]);
                        int diameter = Math.min(Math.abs(startX-endX), Math.abs(startY-endY));
                        g.drawOval(Math.min(startX,endX), Math.min(startY, endY), diameter, diameter);
                        break;
                    case "Rect":
                        t=Integer.parseInt(record[1]);
                        g.setStroke(new BasicStroke(t));
                        red =Integer.parseInt(record[2]);
                        green = Integer.parseInt(record[3]);
                        blue = Integer.parseInt(record[4]);
                        color= new Color(red, green, blue);
                        g.setColor(color);
                        startX=Integer.parseInt(record[5]);
                        startY=Integer.parseInt(record[6]);
                        endX =Integer.parseInt(record[7]);
                        endY=Integer.parseInt(record[8]);
                        g.drawRect(Math.min(startX,endX), Math.min(startY, endY), Math.abs(startX-endX), Math.abs(startY-endY));
                        break;
                    case "Text":
                        t=Integer.parseInt(record[1]);
                        Font f = new Font(null, Font.PLAIN, t+10);
                        g.setFont(f);
                        red =Integer.parseInt(record[2]);
                        green = Integer.parseInt(record[3]);
                        blue = Integer.parseInt(record[4]);
                        color= new Color(red, green, blue);
                        g.setColor(color);
                        startX=Integer.parseInt(record[5]);
                        startY=Integer.parseInt(record[6]);
                        String text=record[7];
                        g.drawString(text, startX, startY);
                        break;
                    case "Line":
                        t=Integer.parseInt(record[1]);
                        g.setStroke(new BasicStroke(t));
                        red =Integer.parseInt(record[2]);
                        green = Integer.parseInt(record[3]);
                        blue = Integer.parseInt(record[4]);
                        color= new Color(red, green, blue);
                        g.setColor(color);
                        startX=Integer.parseInt(record[5]);
                        startY=Integer.parseInt(record[6]);
                        endX =Integer.parseInt(record[7]);
                        endY=Integer.parseInt(record[8]);
                        g.drawLine(startX, startY, endX, endY);
                        break;
                    case "Oval":
                        t=Integer.parseInt(record[1]);
                        g.setStroke(new BasicStroke(t));
                        red =Integer.parseInt(record[2]);
                        green = Integer.parseInt(record[3]);
                        blue = Integer.parseInt(record[4]);
                        color= new Color(red, green, blue);
                        g.setColor(color);
                        startX=Integer.parseInt(record[5]);
                        startY=Integer.parseInt(record[6]);
                        endX =Integer.parseInt(record[7]);
                        endY=Integer.parseInt(record[8]);
                        g.drawOval(Math.min(startX, endX),Math.min(startY, endY), Math.abs(startX-endX), Math.abs(startY-endY));
                        break;
                    default:
                        break;
                }
            }
        }catch (Exception e){

        }
    }
}

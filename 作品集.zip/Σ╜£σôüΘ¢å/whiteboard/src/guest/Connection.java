package guest;
import javax.swing.*;
import java.io.DataInputStream;
import java.io.DataOutputStream;
import java.io.IOException;
import java.net.Socket;

public class Connection {
    private Socket socket;
    public DataInputStream dis =null;
    public static DataOutputStream dos=null;

    String status;
    boolean kick = false;


    public void launch(){
        try{
            while(true){
                String request=dis.readUTF();
                String[] splitedRequest =request.split(" ", 2);
                if (splitedRequest[0].equals("draw")){
                    Guest.listener.update(splitedRequest[1]);
                    Guest.canvasPainter.repaint();
                }
                if (splitedRequest[0].equals("chat")){
                    Join.gui.guestTextArea.append(splitedRequest[1]+"\n");
                }
                if (splitedRequest[0].equals("userlist") && Join.gui != null){
                    Join.gui.list.setListData(splitedRequest[1].split(" "));
                }
                if (splitedRequest[0].equals("delete")){
                    String[] users = splitedRequest[1].split(" ", 2);
                    String[] userList = users[1].split(" ");
                    JOptionPane.showMessageDialog(Join.gui.frame, users[0] + "has been kicked out by manager");
                    Join.gui.list.setListData(userList);

                }
                if (splitedRequest[0].equals("kick")){
                    kick = true;
                    JOptionPane.showMessageDialog(Join.gui.frame, "You have been kicked out by manager");
                }

                if(splitedRequest[0].equals("feedback")){
                    if (splitedRequest[1].equals("no")){
                        status="no";
                    } else if(splitedRequest[1].equals("yes")){
                        status ="yes";
                    } else if(splitedRequest[1].equals("rejected")){
                        status ="rejected";
                    }
                }
                if (splitedRequest[0].equals("clientout")){
                    String[] users = splitedRequest[1].split(" ", 2);
                    JOptionPane.showMessageDialog(Join.gui.frame, "user "+users[0]+" leaves!");
                    String[] userList = users[1].split(" ");
                    Join.gui.list.setListData(userList);
                }
                if (splitedRequest[0].equals("new")){
                    Guest.canvasPainter.removeAll();
                    Guest.canvasPainter.updateUI();
                    Guest.listener.clearRecord();
                }
            }
        }catch(IOException e1){
            try{
                if (!kick){
                    JOptionPane.showMessageDialog(Join.gui.frame, "Disconnected with server");
                }
            }catch(Exception e){}
            System.exit(0);

        }
    }

    Connection(Socket socket){
        resetStatus();
        try{
            this.socket=socket;
            dos=new DataOutputStream(this.socket.getOutputStream());
            dis=new DataInputStream(this.socket.getInputStream());
        }catch(Exception e){}
    }

    String getCurrentStatus(){
        return status;
    }

    public void resetStatus(){
        status ="wait";
        return;
    }
}











package FinalProject;
/*
 * Student name: Zhixuan Ye
 * Student ID: 1286227
 * LMS username: ZHIXUAN1
 */

public class Member {
    private int memberId;
    private String memberName;
    private String email;

    /**
     * members will be created when the dataprovider read the members.csv file;
     * @param memberId member's id
     * @param memberName member's name
     * @param email member's email
     */
    public Member(int memberId, String memberName, String email) {
        this.memberId = memberId;
        this.memberName = memberName;
        this.email = email;
    }


    public int getMemberId() {
        return memberId;
    }

    public void setMemberId(int memberId) {
        this.memberId = memberId;
    }

    public String getMemberName() {
        return memberName;
    }

    public void setMemberName(String memberName) {
        this.memberName = memberName;
    }
}


package FinalProject;
/*
 * Student name: Zhixuan Ye
 * Student ID: 1286227
 * LMS username: ZHIXUAN1
 */

import java.io.Serializable;
import java.util.ArrayList;
import java.util.Scanner;


/**
 * Competition is the father of Randompick and luckyNumber competition, both competition extends all
 * the instance variables and public method. The aim of this class is to decrease the duplicate code;
 * instance variable test represents which mode the competition belongs to.
 */
public abstract class Competition implements Serializable {
    private String name;
    private int id;

    public abstract void addEntries(Bill bill, Scanner scanner);

    private boolean active;
    private ArrayList<Entry> entries = new ArrayList<>();

    public abstract void drawWinners(ArrayList<Member> members);

    private boolean test;
    private ArrayList<Entry> winnerEntry = new ArrayList<>();


    public ArrayList<Entry> getWinnerEntry() {
        return winnerEntry;
    }

    public void setWinnerEntry(ArrayList<Entry> winnerEntry) {
        this.winnerEntry = winnerEntry;
    }

    /**
     * We only need id, holiday name, and test to create a competition. Since the competition
     * will be stay active before we draw winner, the initial value of a new competition object
     * is always true;
     * @param id  competition id
     * @param holidayName the name of the competition
     * @param test weather is in testing mode
     */
    public Competition(int id, String holidayName, boolean test) {
        name = holidayName;
        this.id = id;
        active = true;
        this.test = test;

    }


    public boolean isTest() {
        return test;
    }

    public void setTest(boolean test) {
        this.test = test;
    }

    public boolean isActive() {
        return active;
    }

    public ArrayList<Entry> getEntries() {
        return entries;
    }

    public void setEntries(ArrayList<Entry> enries) {
        this.entries = enries;
    }

    public void setActive(boolean active) {
        this.active = active;
    }

    public String getName() {
        return name;
    }

    public int getId() {
        return id;
    }


    public void setName(String name) {
        this.name = name;
    }

    public void setId(int id) {
        this.id = id;
    }


}


package FinalProject;
/*
 * Student name: Zhixuan Ye
 * Student ID: 1286227
 * LMS username: ZHIXUAN1
 */

import java.util.ArrayList;
import java.util.Arrays;
import java.util.Scanner;

public class NumbersEntry extends Entry {


    public NumbersEntry() {
        super();


    }

    /**
     * this method will change the value of some variable;
     * @param id entry id
     * @param bill a bill object
     * @param scanner
     * @param numbers legal entry's numbers
     */
    public void aEntry(int id, Bill bill, Scanner scanner, int[] numbers) {
        setNumbers(numbers);
        setEntryId(id);
        setMemberId(bill.getMemberId());
        setBillId(bill.getBillId());
    }




}


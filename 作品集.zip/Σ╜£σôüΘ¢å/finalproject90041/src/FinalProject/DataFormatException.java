package FinalProject;
/*
 * Student name: Zhixuan Ye
 * Student ID: 1286227
 * LMS username: ZHIXUAN1
 */

/**
 * This class is for dataprovider's construction to throws. Once it is throws in a object's constructor
 * we need to write catch when we create the object;
 */
public class DataFormatException extends Exception {

}

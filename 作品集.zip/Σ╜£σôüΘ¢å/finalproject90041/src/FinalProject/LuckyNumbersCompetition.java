package FinalProject;
/*
 * Student name: Zhixuan Ye
 * Student ID: 1286227
 * LMS username: ZHIXUAN1
 */

import java.util.*;

public class LuckyNumbersCompetition extends Competition {

    /**
     * This class extend all public methods, instance variable and consrcutor from competition class
     * @param id competition id
     * @param holidayName lucky competition name
     * @param test competition mod
     */
    public LuckyNumbersCompetition(int id, String holidayName, boolean test) {
        super(id, holidayName, test);
    }


    /**
     * this is used to check that the user type the correct number.if correct, return T, else return false
     * @param string the stuff that user type
     * @param number used to compare with string variable
     * @return boolean true or false
     */
    public boolean intCheck(String string, int number) {
        try {
            int a = Integer.parseInt(string);
            if (a >= 0 && a <= number) {
                return true;
            } else {
                System.out.println("The number must be in the range from 0 to " + number + ". Please try again.");
                return false;
            }
        } catch (NumberFormatException e) {
            System.out.println("Invalid input! Numbers are expected. Please try again!");
            return false;
        }
    }

    /**
     * This is a method that test if an array has distinct numbers. if there is distinct number,
     * return false, else return true
     * @param values the whole array
     * @param <T>
     * @return boolean true or false
     */
    public static <T> boolean isDuplicate(final T[] values) {
        Set set = new HashSet<T>();
        for (T s : values) {
            if (set.contains(s)) return true;
            set.add(s);
        }
        return false;
    }

    /**
     * This method test if the input command is legal including test the array length, test if all the
     * item of the input is number, test each number's range, test if there is any distinct item in the
     * array.
     * @param string input numbers (eg: 2 4 6 8 4 2 2)
     * @param scanner
     * @return boolean true or false
     */
    public boolean checkk(String string, Scanner scanner) {
        String[] inPut = string.split(" ");
        if (inPut.length > 7) {
            System.out.println("Invalid input! More than 7 numbers are provided. Please try again!");
            return false;
        } else if (inPut.length < 7) {
            System.out.println("Invalid input! Fewer than 7 numbers are provided. Please try again!");
            return false;
        } else {
            try {
                for (String str : inPut) {
                    int num = Integer.parseInt(str);
                    if (num <= 0 || num > 35) {
                        System.out.println("Invalid input! All numbers must be in the range from 1 to 35!");
                        return false;
                    }
                }
                if (isDuplicate(inPut)) {
                    System.out.println("Invalid input! All numbers must be different!");
                    return false;
                }
                return true;
            } catch (NumberFormatException e) {
                System.out.println("Invalid input! Numbers are expected. Please try again!");
                return false;
            }


        }

    }

    /**
     * This method will firstly check if the input command is legal. if false, do the recursion. if true, it
     * will generate a numberentry object and print out the info of this object.
     * @param bill a bill object
     * @param scanner
     * @param k this is used to debug and print the "The following entries have been added:"
     */
    public void number(Bill bill, Scanner scanner, Boolean k) {
        System.out.println("Please enter 7 different numbers (from the range 1 to 35) separated by whitespace.");
        String numbers = scanner.nextLine();
        if (!checkk(numbers, scanner)) {
            number(bill, scanner, k);
            return;
        }
        String[] inPut = numbers.split(" ");
        int[] array = new int[7];

        for (int i = 0; i < inPut.length; i++) {
            array[i] = Integer.valueOf(inPut[i]);
        }
        ;

        if (k) {
            System.out.println("The following entries have been added:");
        }
        Arrays.sort(array);
        int ID = getEntries().size() + 1;
        NumbersEntry Num = new NumbersEntry();
        Num.aEntry(ID, bill, scanner, array);
        addOne(Num);
        if (ID < 10) {
            System.out.print("Entry ID: " + ID + "      ");
        } else {
            System.out.print("Entry ID: " + ID + "     ");
        }

        System.out.print("Numbers:");
        int[] arr1 = new int[Num.getNumbers().length];
        arr1 = Num.getNumbers();
        for (int j = 0; j < arr1.length; j++) {
            if (arr1[j] < 10) {
                System.out.print("  " + arr1[j]);
            } else {
                System.out.print(" " + arr1[j]);
            }
        }
        System.out.println();


    }


    /**
     * This is the addentries for lucky competition. once the bill is loaded here, this method will
     * evalueate how many entry this bill can create. Then this method will ask user's opion to create
     * the amount of autonumbersentry and numbersentry
     * @param bill a bill object
     * @param scanner
     */
    @Override
    public void addEntries(Bill bill, Scanner scanner) {

        double time = Math.floor(bill.getTotalAmount() / 50);
        int number = (int) time;
        System.out.println("This bill ($" + bill.getTotalAmount() + ") is " +
                "eligible for " + number + " entries. How many manual " +
                "entries did the customer fill up?: ");
        String timess = scanner.nextLine();
        while (!intCheck(timess, number)) {
            timess = scanner.nextLine();
        }
        int a = Integer.parseInt(timess);

        boolean k = true;
        for (int i = 0; i < a; i++) {
            number(bill, scanner, k);
            k = false;
        }

        int auto = number - a;

        if (auto == number) {
            System.out.println("The following entries have been added:");
        }
        for (int i = 0; i < auto; i++) {
            int id = getEntries().size() + 1;
            AutoNumbersEntry autoNum = new AutoNumbersEntry();
            int autoSeed = id - 1;
            autoNum.oneEntry(id, autoSeed, bill, isTest());


            addOne(autoNum);

            if (id < 10) {
                System.out.print("Entry ID: " + id + "      ");
            } else {
                System.out.print("Entry ID: " + id + "     ");
            }

            System.out.print("Numbers:");
            int[] arr = autoNum.getNumbers();
            for (int j = 0; j < arr.length; j++) {
                if (arr[j] < 10) {
                    System.out.print("  " + arr[j]);
                } else {
                    System.out.print(" " + arr[j]);
                }
            }
            System.out.print(" [Auto]");
            System.out.println();

        }
        bill.setUsed(true);

    }


    /**
     * This method is used to add more entry into the entry list
     * @param entry a entryobject
     */
    public void addOne(Entry entry) {
        ArrayList<Entry> allEntries = getEntries();
        allEntries.add(entry);
        setEntries(allEntries);
    }


    /**
     * we first get the lucky number of the lucky competition and we for loop all the entry.
     * we use temp arraylist to store the entris with the same memberid and get the maximum prize
     * of the temp, then store into competition's winner entries;
     * @param members
     */
    @Override
    public void drawWinners(ArrayList<Member> members) {
        AutoNumbersEntry luckyNumber = new AutoNumbersEntry();
        luckyNumber.oneEntry(getId(), isTest());
        System.out.print("Lucky Numbers:");
        int[] arr2 = luckyNumber.getNumbers();
        boolean x;
        Entry max = null;
        for (int i = 0; i < arr2.length; i++) {
            if (arr2[i] < 10) {
                System.out.print("  " + arr2[i]);
            } else {
                System.out.print(" " + arr2[i]);
            }

        }
        System.out.print(" [Auto]");
        System.out.println();

        for (Entry eachEntry : getEntries()) {
            int many = compareNum(arr2, eachEntry.getNumbers());
            int prize = Prize(many);
            eachEntry.setPrize(prize);
        }

        for (int i = 0; i < getEntries().size() - 1; i++) {
            int memberId = getEntries().get(i).getMemberId();
            x = false;

            if (getWinnerEntry().size() != 0) {
                for (Entry eachWinner : getWinnerEntry()) {
                    if (memberId == eachWinner.getMemberId()) {
                        x = true;
                        break;
                    }
                }
            }
            if (!x) {
                ArrayList<Entry> tempList = new ArrayList<>();
                tempList.add(getEntries().get(i));
                for (int j = i + 1; j < getEntries().size(); j++) {
                    if (getEntries().get(i).getMemberId() == getEntries().get(j).getMemberId()) {
                        tempList.add(getEntries().get(j));
                    }
                }
                if (tempList.size() != 0) {
                    max = tempList.get(0);
                    for (int k = 1; k < tempList.size(); k++) {
                        if (max.getPrize() < tempList.get(k).getPrize()) {
                            max = tempList.get(k);
                        }
                    }
                }
                ArrayList<Entry> previousWinner = getWinnerEntry();
                if (max.getPrize() > 0) {
                    previousWinner.add(max);
                }
                setWinnerEntry(previousWinner);
            }
        }

        ArrayList<Entry> rearange = getWinnerEntry();
        Collections.sort(rearange);
        setWinnerEntry(rearange);
        System.out.println("Winning entries:");
        for (Entry eachEntry : getWinnerEntry()) {
            winnerInformation(eachEntry, members);
            if (eachEntry instanceof AutoNumbersEntry) {
                System.out.print("--> Entry ID: " + eachEntry.getEntryId() + ", Numbers:");
                ((AutoNumbersEntry) eachEntry).numbersOutput();
                System.out.println();
            } else {
                System.out.print("--> Entry ID: " + eachEntry.getEntryId() + ", Numbers:");
                for (int i = 0; i < eachEntry.getNumbers().length; i++) {
                    if (eachEntry.getNumbers()[i] < 10) {
                        System.out.print("  " + eachEntry.getNumbers()[i]);
                    } else {
                        System.out.print(" " + eachEntry.getNumbers()[i]);
                    }
                    System.out.println();
                }
            }
        }

    }


    /**
     * this method print out the customer's info and the entryinfo of the winning entry
     * @param entry entry object
     * @param members all member objects
     */
    public void winnerInformation(Entry entry, ArrayList<Member> members) {
        int memberId = entry.getMemberId();
        String name = null;
        for (Member eachMember : members) {
            if (eachMember.getMemberId() == memberId) {
                name = eachMember.getMemberName();
            }
        }
        if (entry.getPrize() < 100) {
            System.out.println("Member ID: " + entry.getMemberId() + ", Member Name: "
                    + name + ", Prize: " + entry.getPrize() + "   ");
        } else if (entry.getPrize() < 1000) {
            System.out.println("Member ID: " + entry.getMemberId() + ", Member Name: "
                    + name + ", Prize: " + entry.getPrize() + "  ");
        } else if (entry.getPrize() < 10000) {
            System.out.println("Member ID: "
                    + entry.getMemberId() + ", Member Name: "
                    + name + ", Prize: " + entry.getPrize() + " ");
        } else {
            System.out.println("Member ID: "
                    + entry.getMemberId() + ", Member Name: "
                    + name + ", Prize: " + entry.getPrize());
        }
    }

    /**
     * this method returns match number bwtween one entry's number and lucky number
     * @param luckyNum lucky number
     * @param oneEntry entry's number
     * @return int totalmatch
     */
    public int compareNum(int[] luckyNum, int[] oneEntry) {
        int totalMatch = 0;
        for (int i = 0; i < luckyNum.length; i++) {
            for (int j = 0; j < oneEntry.length; j++) {
                if (luckyNum[i] == oneEntry[j]) {
                    totalMatch = totalMatch + 1;
                }
            }
        }
        return totalMatch;
    }


    /**
     *
     * @param prizeNum how many prize number an entry contain
     * @return prize corresponding to the prize number
     */
    public int Prize(int prizeNum) {
        if (prizeNum == 1) {
            return 0;
        } else if (prizeNum == 2) {
            return 50;
        } else if (prizeNum == 3) {
            return 100;
        } else if (prizeNum == 4) {
            return 500;
        } else if (prizeNum == 5) {
            return 1000;
        } else if (prizeNum == 6) {
            return 5000;
        } else if (prizeNum == 7) {
            return 50000;
        }

        return 0;
    }


}


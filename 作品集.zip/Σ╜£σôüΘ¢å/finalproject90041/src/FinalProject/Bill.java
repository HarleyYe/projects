package FinalProject;
/*
 * Student name: Zhixuan Ye
 * Student ID: 1286227
 * LMS username: ZHIXUAN1
 */

/**
 * This class has four instance variable billID, memberId, totalAmount, and used.
 * The bill object will be created in dataprovider class by reading the bills.csv
 * file.
 */
public class Bill {
    private int billId;
    private int memberId;
    private float totalAmount;
    private boolean used;

    /**
     *
     * @param billId a bill's id
     * @param memberId a bill's member id
     * @param totalAmount the total amount of this bill
     * @param used is this bill used for any competition before
     */
    public Bill(int billId, int memberId, float totalAmount, boolean used) {
        this.billId = billId;
        this.memberId = memberId;
        this.totalAmount = totalAmount;
        this.used = used;

    }


    public int getBillId() {
        return billId;
    }

    public void setBillId(int billId) {
        this.billId = billId;
    }

    public int getMemberId() {
        return memberId;
    }

    public void setMemberId(int memberId) {
        this.memberId = memberId;
    }

    public float getTotalAmount() {
        return totalAmount;
    }

    public void setTotalAmount(float totalAmount) {
        this.totalAmount = totalAmount;
    }

    public boolean isUsed() {
        return used;
    }

    public void setUsed(boolean used) {
        this.used = used;
    }
}


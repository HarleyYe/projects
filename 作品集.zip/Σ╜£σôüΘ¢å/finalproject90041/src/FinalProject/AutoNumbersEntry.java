package FinalProject;

/*
 * Student name: Zhixuan Ye
 * Student ID: 1286227
 * LMS username: ZHIXUAN1
 */

import java.util.*;

/**
 * This class can generate an entry automatically. This class extends all the instance variables
 * and public methods from the NumbersEntry and Entry.
 *
 */
public class AutoNumbersEntry extends NumbersEntry {
    private final int NUMBER_COUNT = 7;
    private final int MAX_NUMBER = 35;
    private static final Scanner scanner = new Scanner(System.in);

    public AutoNumbersEntry() {
        super();

    }


    /**
     * This is the constractor of the this class. we need three inputs to generate random entry number
     * for random competition.
     * @param id entry id
     * @param bill a bill object
     * @param test weather current competition is in testing mode or not
     */
    public void oneEntry(int id, Bill bill, boolean test) {
        setEntryId(id);
        setMemberId(bill.getMemberId());
        setBillId(bill.getBillId());
        if (test) {
            setNumbers(createNumbers(id));
        } else {
            setNumbers(createNumbers());
        }

    }


    /**
     * This is an overload constractor, used for luck competition's auto entry
     * @param id entry id
     * @param autoSeed entryid-1
     * @param bill a bill object
     * @param test weather current competition is in testing mode or not
     */
    public void oneEntry(int id, int autoSeed, Bill bill, boolean test) {

        setEntryId(id);
        setMemberId(bill.getMemberId());
        setBillId(bill.getBillId());
        if (test) {
            setNumbers(createNumbers(autoSeed));
        } else {
            setNumbers(createNumbers());
        }

    }


    /**
     * This constructor is for luckCompetition's lucky number, it will create the random number based on
     * entry id if the lucky competition is in testing mode.
     * @param id entry number
     * @param test weather current competition is in testing mode or not
     */
    public void oneEntry(int id, boolean test) {
        if (test) {
            setNumbers(createNumbers(id));
        } else {
            setNumbers(createNumbers());
        }
    }

    /**
     * This method return a array with 7 random numbers. this method is specifically for testing mode
     * competition.
     * @param seed it is the entry number
     * @return tempNumbers
     */
    public int[] createNumbers(int seed) {
        ArrayList<Integer> validList = new ArrayList<Integer>();
        int[] tempNumbers = new int[NUMBER_COUNT];
        for (int i = 1; i <= MAX_NUMBER; i++) {
            validList.add(i);
        }
        Collections.shuffle(validList, new Random(seed));
        for (int i = 0; i < NUMBER_COUNT; i++) {
            tempNumbers[i] = validList.get(i);
        }
        Arrays.sort(tempNumbers);
        return tempNumbers;
    }

    /**
     * This method used in RandomPickCompetition class's drawwinner method, it can
     * print entry's number with valid form.
     */
    public void numbersOutput() {
        for (int i = 0; i < getNumbers().length; i++) {
            if (getNumbers()[i] < 10) {
                System.out.print("  " + getNumbers()[i]);
            } else {
                System.out.print(" " + getNumbers()[i]);
            }

        }
        System.out.print(" [Auto]");

    }

    /**
     * This is a overload method. This method aims to create and return a array with 7 random numbers.
     * This method is specifically for normal mode competition
     * @return tempNumbers an array
     */
    public int[] createNumbers() {
        ArrayList<Integer> validList = new ArrayList<Integer>();
        int[] tempNumbers = new int[NUMBER_COUNT];
        for (int i = 1; i <= MAX_NUMBER; i++) {
            validList.add(i);
        }
        Collections.shuffle(validList, new Random());
        for (int i = 0; i < NUMBER_COUNT; i++) {
            tempNumbers[i] = validList.get(i);
        }
        Arrays.sort(tempNumbers);
        return tempNumbers;
    }


}


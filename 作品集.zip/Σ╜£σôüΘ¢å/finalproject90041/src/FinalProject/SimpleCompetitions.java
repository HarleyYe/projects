package FinalProject;
/*
 * Student name: Zhixuan Ye
 * Student ID: 1286227
 * LMS username: ZHIXUAN1
 */

import java.io.*;
import java.util.*;

public class SimpleCompetitions {
    /**
     * This class is the main class of this project, it have several instance variable to
     * store the current competition, all competitions. dataprovider can provide info about members
     * and bill.
     */
    private DataProvider dataProvider;
    private Competition currentCompetition;
    private ArrayList<Competition> allCompetition = new ArrayList<>();
    private static final Scanner scanner = new Scanner(System.in);

    public ArrayList<Competition> getAllCompetition() {
        return allCompetition;
    }

    public void setAllCompetition(ArrayList<Competition> allCompetition) {
        this.allCompetition = allCompetition;
    }

    /**
     * This method serve for menu:when user type 1 in menu, addNewcompetition will be evoke to
     * create either lucky or random competition based on the user choise
     */
    public void addNewCompetition() {
        System.out.println("Type of competition (L: LuckyNumbers, R: RandomPick)?:");
        String command = scanner.nextLine();
        if (command.equals("L")) {
            System.out.println("Competition name: ");
            String holidayName = scanner.nextLine();
            int id = allCompetition.size() + 1;
            LuckyNumbersCompetition luck = new LuckyNumbersCompetition(id, holidayName, true);
            allCompetition.add(luck);
            currentCompetition = luck;
            System.out.println("A new competition has been created!");
            System.out.println("Competition ID: " + luck.getId() +
                    ", Competition Name: " + luck.getName() +
                    ", Type: LuckyNumbersCompetition");

        } else if (command.equals("R")) {
            int id = allCompetition.size() + 1;
            System.out.println("Competition name: ");
            String holidayName = scanner.nextLine();
            RandomPickCompetition random = new RandomPickCompetition(id, holidayName, true);
            allCompetition.add(random);
            currentCompetition = random;
            System.out.println("A new competition has been created!");
            System.out.println("Competition ID: " + random.getId() +
                    ", Competition Name: " + random.getName() +
                    ", Type: RandomPickCompetition");
        } else {
            System.out.println("Invalid competition type! Please choose again.");
            addNewCompetition();
        }


    }


    /**
     * Main program that uses the main SimpleCompetitions class
     *
     * @param args main program arguments
     */
    public static void main(String[] args) {


        SimpleCompetitions sc = new SimpleCompetitions();
        sc.startApp();

    }

    /**
     * The title of this app, evoke app check method
     */
    public void startApp() {
        System.out.println("----WELCOME TO SIMPLE COMPETITIONS APP----");
        appCheck();

    }

    /**
     * user can choose either load competition or not after startApp method
     */
    public void appCheck() {
        System.out.println("Load competitions from file? (Y/N)?");
        String commands = scanner.nextLine().toLowerCase();
        if (commands.equals("y")) {
            yStart();
        } else if (commands.equals("n")) {
            nStart();
        } else {
            System.out.println("Unsupported option. Please try again!");
            appCheck();
        }
    }


    /**
     * if user choose load competitions, yStart evoked and it will require user type three file names:
     * the compititions will stored in tis class' all competition. members and bills will be store in
     * data provider
     */
    public void yStart() {
        System.out.println("File name:");
        String fileName = scanner.nextLine();
        System.out.println("Member file: ");
        String memberFile = scanner.nextLine();
        System.out.println("Bill file: ");
        String billFile = scanner.nextLine();

        try {
            loadCompetition(fileName);
            dataProvider = new DataProvider(memberFile, billFile);
            if (dataProvider.getMembers().size() != 0 && dataProvider.getBills().size() != 0) {
                menu();
            }
        } catch (DataFormatException e) {
            System.out.println("Invalid input");
        } catch (DataAccessException e) {
            System.out.println("....");
        }


    }

    /**
     * This method can read the binary file and stored it into the allcompetition arraylist
     * @param fileName filename for all competitions
     */
    public void loadCompetition(String fileName) {
        try {
            ObjectInputStream ois = new ObjectInputStream(new FileInputStream(fileName));
            allCompetition = (ArrayList<Competition>) (ois.readObject());
            if (allCompetition.get(allCompetition.size() - 1).isActive()) {
                currentCompetition = allCompetition.get(allCompetition.size() - 1);
            }

        } catch (FileNotFoundException e) {
            e.printStackTrace();
        } catch (IOException e) {
            e.printStackTrace();
        } catch (ClassNotFoundException e) {
            e.printStackTrace();
        }
    }


    /**
     * This methos is very similar to addNewCompetition, but this method is to create a
     * normal form competition
     */
    public void addNewCompetitionforN() {
        System.out.println("Type of competition (L: LuckyNumbers, R: RandomPick)?:");
        String command = scanner.nextLine();
        if (command.equals("L")) {
            System.out.println("Competition name: ");
            String holidayName = scanner.nextLine();
            int id = allCompetition.size() + 1;
            LuckyNumbersCompetition luck = new LuckyNumbersCompetition(id, holidayName, false);
            allCompetition.add(luck);
            currentCompetition = luck;
            System.out.println("A new competition has been created!");
            System.out.println("Competition ID: " + luck.getId() +
                    ", Competition Name: " + luck.getName() +
                    ", Type: LuckyNumbersCompetition");

        } else if (command.equals("R")) {
            int id = allCompetition.size() + 1;
            System.out.println("Competition name: ");
            String holidayName = scanner.nextLine();
            RandomPickCompetition random = new RandomPickCompetition(id, holidayName, false);
            allCompetition.add(random);
            currentCompetition = random;
            System.out.println("A new competition has been created!");
            System.out.println("Competition ID: " + random.getId() +
                    ", Competition Name: " + random.getName() +
                    ", Type: RandomPickCompetition");
        } else {
            System.out.println("Invalid competition type! Please choose again.");
            addNewCompetition();
        }
    }


    /**
     * this is the menu for normal forms
     */
    public void nmenu() {
        System.out.println("Please select an option. Type 5 to exit.");
        System.out.println("1. Create a new competition\n" +
                "2. Add new entries\n" +
                "3. Draw winners\n" +
                "4. Get a summary report\n" +
                "5. Exit");
        String command = scanner.nextLine();
        if (checkInt(command) == 0) {
            System.out.println("A number is expected. Please try again.");
            menu();
        } else {
            switch (command) {
                case "1":
                    if (currentCompetition == null) {
                        addNewCompetitionforN();
                        menu();
                    } else {
                        System.out.println("There is an active competition. SimpleCompetitions " +
                                "does not support concurrent competitions!");
                        menu();
                    }
                    break;
                case "2":
                    if (currentCompetition == null) {
                        System.out.println("There is no active competition. Please create one!");
                        menu();
                    } else {

                        entriesCheck();
                        menu();

                    }
                    break;
                case "3":
                    if (currentCompetition == null) {
                        System.out.println("There is no active competition. Please create one!");
                        menu();
                    } else {
                        if (currentCompetition.getEntries().size() == 0) {
                            System.out.println("The current competition has no entries yet!");
                            menu();
                        } else {
                            winnerInfo();
                            menu();
                        }
                    }
                    break;
                case "4":
                    if (allCompetition.size() == 0) {
                        System.out.println("No competition has been created yet!");
                        menu();
                    } else {
                        report(allCompetition);
                        menu();
                    }
                    break;
                case "5":
                    leaveCheck();
                    System.exit(0);
                    break;
                default:
                    System.out.println("Unsupported option. Please try again!");
                    menu();
                    break;
            }
        }

    }


    /**
     * this is the method for user who choose not load competitions. members and bill file are required;
     * there are two competition mode here. if the user choose T and dataprovider successfully created, it
     * will evoke menu method. if the user choose N and dataprovider successfully created, it will evoke
     * nmenu method
     */
    public void nStart() {
        System.out.println("Which mode would you like to run? (Type T for Testing, and N for Normal mode):");
        String command = scanner.nextLine().toLowerCase();
        if (command.equals("t")) {
            System.out.println("Member file: ");
            String memberFile = scanner.nextLine();
            System.out.println("Bill file: ");
            String billFile = scanner.nextLine();
            try {
                dataProvider = new DataProvider(memberFile, billFile);
                if (dataProvider.getMembers().size() != 0 && dataProvider.getBills().size() != 0) {
                    menu();
                }

            } catch (DataFormatException e) {
                e.printStackTrace();
            } catch (DataAccessException e) {
                e.printStackTrace();
            }


        } else if (command.equals("n")) {
            System.out.println("Member file: ");
            String memberFile = scanner.nextLine();
            System.out.println("Bill file: ");
            String billFile = scanner.nextLine();
            try {
                dataProvider = new DataProvider(memberFile, billFile);
                if (dataProvider.getMembers().size() != 0 && dataProvider.getBills().size() != 0) {
                    nmenu();
                }

            } catch (DataFormatException e) {
                e.printStackTrace();
            } catch (DataAccessException e) {
                e.printStackTrace();
            }


        } else {
            System.out.println("Invalid mode! Please choose again.");
            nStart();
        }

    }

    /**
     * this is the menu method only for user who choose the testing form
     */
    public void menu() {
        System.out.println("Please select an option. Type 5 to exit.");
        System.out.println("1. Create a new competition\n" +
                "2. Add new entries\n" +
                "3. Draw winners\n" +
                "4. Get a summary report\n" +
                "5. Exit");
        String command = scanner.nextLine();
        if (checkInt(command) == 0) {
            System.out.println("A number is expected. Please try again.");
            menu();
        } else {
            switch (command) {
                case "1":
                    if (currentCompetition == null) {
                        addNewCompetition();
                        menu();
                    } else {
                        System.out.println("There is an active competition. SimpleCompetitions " +
                                "does not support concurrent competitions!");
                        menu();
                    }
                    break;
                case "2":
                    if (currentCompetition == null) {
                        System.out.println("There is no active competition. Please create one!");
                        menu();
                    } else {

                        entriesCheck();
                        menu();

                    }
                    break;
                case "3":
                    if (currentCompetition == null) {
                        System.out.println("There is no active competition. Please create one!");
                        menu();
                    } else {
                        if (currentCompetition.getEntries().size() == 0) {
                            System.out.println("The current competition has no entries yet!");
                            menu();
                        } else {
                            winnerInfo();
                            menu();
                        }
                    }
                    break;
                case "4":
                    if (allCompetition.size() == 0) {
                        System.out.println("No competition has been created yet!");
                        menu();
                    } else {
                        report(allCompetition);
                        menu();
                    }
                    break;
                case "5":
                    leaveCheck();
                    System.exit(0);
                    break;
                default:
                    System.out.println("Unsupported option. Please try again!");
                    menu();
                    break;
            }
        }

    }


    /**
     * it will print out the privous competitions info and the current competition's info
     * @param competitions all competitions
     */
    public void report(ArrayList<Competition> competitions) {
        System.out.println("----SUMMARY REPORT----");
        if (competitions.get(competitions.size() - 1).isActive()) {
            int completed = competitions.size() - 1;
            System.out.println("+Number of completed competitions: " + completed
                    + "\n" +
                    "+Number of active competitions: 1");
        } else {
            int completed = competitions.size();
            System.out.println("+Number of completed competitions: " + completed
                    + "\n" +
                    "+Number of active competitions: 0");
        }
        for (Competition eachCompetition : competitions) {
            if (!eachCompetition.isActive()) {
                System.out.println();
                System.out.println("Competition ID: " + eachCompetition.getId() +
                        ", name: " + eachCompetition.getName() + ", active: no\n" +
                        "Number of entries: " + eachCompetition.getEntries().size());
                System.out.println("Number of winning entries: " + eachCompetition.getWinnerEntry().size());
                int total = 0;
                for (Entry eachWinner : eachCompetition.getWinnerEntry()) {
                    total = total + eachWinner.getPrize();
                }
                System.out.println("Total awarded prizes: " + total);
            } else {
                System.out.println();
                System.out.println("Competition ID: " + eachCompetition.getId() +
                        ", name: " + eachCompetition.getName() + ", active: yes\n" +
                        "Number of entries: " + eachCompetition.getEntries().size());
            }
        }

    }


    /**
     * This method connect to the current-competition's draw-winner.
     */
    public void winnerInfo() {
        if (currentCompetition instanceof LuckyNumbersCompetition) {

            System.out.println("Competition ID: " + currentCompetition.getId() + ", Competition Name: " +
                    currentCompetition.getName() + ", Type: LuckyNumbersCompetition");
        } else {
            System.out.println("Competition ID: " + currentCompetition.getId() + ", Competition Name: " +
                    currentCompetition.getName() + ", Type: RandomPickCompetition");
        }
        currentCompetition.drawWinners(dataProvider.getMembers());
        currentCompetition.setActive(false);
        currentCompetition = null;
    }


    /**
     * Ask the user whether would like to save all the competitions and the bills before they leave
     */
    public void leaveCheck() {
        System.out.println("Save competitions to file? (Y/N)?");
        String command = scanner.nextLine().toLowerCase();
        if (command.equals("y")) {
            System.out.println("File name:");
            String fileName = scanner.nextLine();
            try {
                ObjectOutputStream oos = new ObjectOutputStream(new FileOutputStream(fileName));
                oos.writeObject(allCompetition);
                oos.close();
                System.out.println("Competitions have been saved to file.");

                BufferedWriter bw = new BufferedWriter(new FileWriter("bills.csv"));
                String sMemberId;
                for (Bill eachBill : dataProvider.getBills()) {
                    int memberId = eachBill.getMemberId();
                    if (memberId == 0) {
                        sMemberId = "";
                    } else {
                        sMemberId = String.valueOf(memberId);
                    }
                    bw.write(eachBill.getBillId() + "," + sMemberId + "," + eachBill.getTotalAmount() + ","
                            + eachBill.isUsed());
                    bw.newLine();
                }
                bw.close();
                System.out.println("The bill file has also been automatically updated.");
                System.out.println("Goodbye!");

            } catch (FileNotFoundException e) {
                System.out.println("Invalid file");
            } catch (IOException e) {
                System.out.println("IO exception");
            }
        } else if (command.equals("n")) {
            System.out.println("Goodbye!");
        } else {
            System.out.println("Invalid command, please try again!");
            leaveCheck();
        }
    }


    /**
     * This method check if the bill is available for add entry:1.bill object has memberid
     * 2. bill id is not used 3. the bill id exist 4. the bill id follows valid rule
     */
    public void entriesCheck() {
        System.out.println("Bill ID: ");
        String bill = scanner.nextLine();
        if (checkInt(bill) == 1) {
            int billID = Integer.parseInt(bill);
            boolean found = false;
            for (Bill eachBill : dataProvider.getBills()) {
                if (eachBill.getBillId() == billID && !eachBill.isUsed()) {
                    if (eachBill.getMemberId() != 0) {
                        found = true;
                        currentCompetition.addEntries(eachBill, scanner);
                        more();

                    } else {
                        System.out.println("This bill has no member id. Please try again.");
                        entriesCheck();
                    }
                }
                if (eachBill.getBillId() == billID && eachBill.isUsed()) {
                    System.out.println("This bill has already been used for a competition. Please try again.");
                    found = true;
                    entriesCheck();
                }
            }
            if (!found) {
                System.out.println("This bill does not exist. Please try again.");
                entriesCheck();

            }
        } else {
            System.out.println("Invalid bill id! It must be a 6-digit number. " +
                    "Please try again.");
            entriesCheck();

        }
    }

    /**
     * This method ask the user want to load more entry after added one entry, and check the input command
     */
    public void more() {
        System.out.println("Add more entries (Y/N)?");
        String output = scanner.nextLine();
        if (output.equals("Y")) {
            entriesCheck();
        } else if (output.equals("N")) {
            menu();
        } else {
            System.out.println("Unsupported option. Please try again!");
            more();
        }
    }


    /**
     * This method can check if the input command is all numbers. 1 means success
     * @param billID a input command
     * @return 0 or 1
     */
    public int checkInt(String billID) {
        try {
            int num = Integer.valueOf(billID);
            return 1;
        } catch (NumberFormatException e) {
            return 0;
        }
    }


}







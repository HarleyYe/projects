package FinalProject;
/*
 * Student name: Zhixuan Ye
 * Student ID: 1286227
 * LMS username: ZHIXUAN1
 */

import java.util.ArrayList;
import java.util.Collections;
import java.util.Random;
import java.util.Scanner;

public class RandomPickCompetition extends Competition {
    private final int FIRST_PRIZE = 50000;
    private final int SECOND_PRIZE = 5000;
    private final int THIRD_PRIZE = 1000;
    private final int[] prizes = {FIRST_PRIZE, SECOND_PRIZE, THIRD_PRIZE};


    private final int MAX_WINNING_ENTRIES = 3;

    /**
     * This method extend all the instance variables, public method and constracutor from competition
     * @param id competition id
     * @param holidayName competition name
     * @param test competition mode
     */
    public RandomPickCompetition(int id, String holidayName, boolean test) {
        super(id, holidayName, test);
    }


    /**
     * When a bill loaded here, this method will evaluate how many autonumbers entry it can
     * genrates and print the entry's information;
     * @param bill a bill object
     * @param scanner
     */
    @Override
    public void addEntries(Bill bill, Scanner scanner) {

        double time = Math.floor(bill.getTotalAmount() / 50);
        int number = (int) time;
        System.out.println("This bill ($" + bill.getTotalAmount() + ") is " +
                "eligible for " + number + " entries.");
        System.out.println("The following entries have been automatically generated:");
        //创建times个
        for (int i = 0; i < number; i++) {
            int id = getEntries().size() + 1;
            AutoNumbersEntry auto = new AutoNumbersEntry();
            auto.oneEntry(id, bill, isTest());
            addOne(auto);
            if (id < 10) {
                System.out.println("Entry ID: " + id + "     ");
            } else {
                System.out.println("Entry ID: " + id + "    ");
            }

        }
        bill.setUsed(true);


    }

    /**
     *
     * @param entry a new entry object that need to be added into the entries list
     */
    public void addOne(Entry entry) {
        ArrayList<Entry> allEntries = new ArrayList<>();
        allEntries = getEntries();
        allEntries.add(entry);
        setEntries(allEntries);

    }

    /**
     * This method can randomly pick three entries as the winner of the competition. Further, this method
     * will check is there is same memberid in the winner entry.if yes, then only keep the entry with the
     * max prize of a member id;
     * @param members
     */
    public void drawWinners(ArrayList<Member> members) {
        Random randomGenerator = null;
        if (this.isTest()) {
            randomGenerator = new Random(this.getId());
        } else {
            randomGenerator = new Random();
        }

        int winningEntryCount = 0;
        while (winningEntryCount < MAX_WINNING_ENTRIES) {
            int winningEntryIndex = randomGenerator.nextInt(getEntries().size());

            Entry winningEntry = getEntries().get(winningEntryIndex);

            if (winningEntry.getPrize() == 0) {
                int currentPrize = prizes[winningEntryCount];
                winningEntry.setPrize(currentPrize);
                winningEntryCount++;
            }
            ArrayList<Entry> moreWining = getWinnerEntry();
            moreWining.add(winningEntry);
            setWinnerEntry(moreWining);
        }

        ArrayList<Entry> Deleteobject = new ArrayList<>();
        for (int i = 0; i < getWinnerEntry().size() - 1; i++) {
            for (int j = i + 1; j < getWinnerEntry().size(); j++) {
                if (getWinnerEntry().get(i).getMemberId() == getWinnerEntry().get(j).getMemberId()) {
                    if (getWinnerEntry().get(i).getPrize() >= getWinnerEntry().get(j).getPrize()) {
                        Deleteobject.add(getWinnerEntry().get(j));
                    } else {
                        Deleteobject.add(getWinnerEntry().get(i));
                    }
                }
            }
        }
        for (Entry eachDelte : Deleteobject) {
            ArrayList<Entry> winnerList = getWinnerEntry();
            winnerList.remove(eachDelte);
            setWinnerEntry(winnerList);
        }

        ArrayList<Entry> rearange = getWinnerEntry();
        Collections.sort(rearange);
        setWinnerEntry(rearange);
        setWinnerEntry(rearange);

        System.out.println("Winning entries:");
        for (Entry eachWinner : getWinnerEntry()) {
            winnerInformation(eachWinner, members);
        }


    }


    /**
     * This methos serve for draw winner to display the winner information and entry info
     * @param entry entry who won prize in a competition
     * @param members all members
     */
    public void winnerInformation(Entry entry, ArrayList<Member> members) {
        int memberId = entry.getMemberId();
        String name = null;
        for (Member eachMember : members) {
            if (eachMember.getMemberId() == memberId) {
                name = eachMember.getMemberName();
            }
        }
        int prize = entry.getPrize();
        if (prize > 9999) {
            System.out.println("Member ID: " + entry.getMemberId() + ", Member Name: "
                    + name + ", Entry ID: " + entry.getEntryId() + ", Prize: " + prize);
        } else {
            System.out.println("Member ID: " + entry.getMemberId() + ", Member Name: "
                    + name + ", Entry ID: " + entry.getEntryId() + ", Prize: " + prize + " ");
        }

    }



}







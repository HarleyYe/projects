package FinalProject;
/*
 * Student name: Zhixuan Ye
 * Student ID: 1286227
 * LMS username: ZHIXUAN1
 */

import java.io.*;
import java.util.ArrayList;
import java.util.Scanner;

public class DataProvider implements Serializable {
    /**
     * this class is used to provide data to simpleCompetitions; When a data provider object
     * is created, memberFile and billFile will be read and stored as two arraylists in dataprovider;
     * @param memberFile A path to the member file (e.g., members.csv)
     * @param billFile A path to the bill file (e.g., bills.csv)
     * @throws DataAccessException If a file cannot be opened/read
     * @throws DataFormatException If the format of the the content is incorrect
     */

    private String memberFile;
    private String billFile;
    private ArrayList<Member> members = new ArrayList<>();
    private ArrayList<Bill> bills = new ArrayList<>();
    private static final Scanner scanner = new Scanner(System.in);


    public DataProvider(String memberFile, String billFile)
            throws DataAccessException, DataFormatException {
        try {
            BufferedReader input = new BufferedReader(new FileReader(memberFile));
            String oneLineInfo = input.readLine();
            while (oneLineInfo != null) {
                String[] Info = oneLineInfo.split(",");
                int memberId = Integer.parseInt(Info[0]);
                String mName = Info[1];
                String email = Info[2];
                Member member = new Member(memberId, mName, email);
                members.add(member);
                oneLineInfo = input.readLine();
            }
            input.close();

            BufferedReader billInput = new BufferedReader(new FileReader(billFile));
            String oneLineInf = billInput.readLine();
            while (oneLineInf != null) {
                String[] readInfo = oneLineInf.split(",");
                int billId = Integer.parseInt(readInfo[0]);
                if (readInfo[1].equals("")) {
                    readInfo[1] = "0";
                }
                int memId = Integer.parseInt(readInfo[1]);
                float amount = Float.valueOf(readInfo[2]).floatValue();
                boolean used = Boolean.parseBoolean(readInfo[3]);
                Bill bill = new Bill(billId, memId, amount, used);
                bills.add(bill);
                oneLineInf = billInput.readLine();
            }
            billInput.close();


        } catch (FileNotFoundException e) {
            e.printStackTrace();
        } catch (IOException e) {
            e.printStackTrace();
        }
    }





    public ArrayList<Member> getMembers() {
        return members;
    }

    public void setMembers(ArrayList<Member> members) {
        this.members = members;
    }

    public ArrayList<Bill> getBills() {
        return bills;
    }

    public void setBills(ArrayList<Bill> bills) {
        this.bills = bills;
    }

}




package FinalProject;
/*
 * Student name: Zhixuan Ye
 * Student ID: 1286227
 * LMS username: ZHIXUAN1
 */

import java.io.Serializable;
import java.util.ArrayList;

public class Entry implements Comparable, Serializable {
    /**
     * This class is the father of the numberEntry and grandfather of autonumbersEntry
     * @param numbers this is an array to store a entry's numbers
     * @param entryId this is the entry identifier
     * @param billId this is record the bill used for create this entry
     * @param memberId this record this entry belongs to whom
     * @param prize this is prize that the entry won in a competition
     */
    private int[] numbers = new int[7];
    private int entryId;
    private int billId;
    private int memberId;
    private int prize;


    public int getPrize() {
        return prize;
    }

    public void setPrize(int prize) {
        this.prize = prize;
    }

    public int[] getNumbers() {
        return numbers;
    }

    public void setNumbers(int[] numbers) {
        this.numbers = numbers;
    }



    public int getEntryId() {
        return entryId;
    }

    public void setEntryId(int entryId) {
        this.entryId = entryId;
    }

    public int getBillId() {
        return billId;
    }

    public void setBillId(int billId) {
        this.billId = billId;
    }

    public int getMemberId() {
        return memberId;
    }

    public void setMemberId(int memberId) {
        this.memberId = memberId;
    }

    @Override
    /**
     * this method is for drawwinner:order the winner entry by the entryid
     */
    public int compareTo(Object o) {
        Entry another = (Entry) o;
        return getEntryId() - another.getEntryId();
    }
}

